define(['cdf/lib/jquery'], function($) {
    
    var utils = {}

    utils.props = {
        
        general : {
            pageTitle : "Overview",
            pageSubTitle : "How are we doing?",
            pageIcon : "fa-home",
            pageBreadcrumb : ["Overview"]
        }
        
    }
    
    return utils;
    
});
        