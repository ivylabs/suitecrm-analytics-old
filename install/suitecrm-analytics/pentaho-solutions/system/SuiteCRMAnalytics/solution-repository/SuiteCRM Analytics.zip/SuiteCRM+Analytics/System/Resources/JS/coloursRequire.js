define(['cdf/lib/jquery'], function($) {
var coloursRequire = {}
    
    coloursRequire.opts = {
        
        charts:{
            
            myColours:{
                colors: ["#ff0000","00ff00","0000ff"]
            }
        },
    }
    return coloursRequire;
});