var myColors = {
    colors: ["#ff0000","00ff00","0000ff"]
}

